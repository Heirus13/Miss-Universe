﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Windows.Forms.VisualStyles;

namespace MissUniverse
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                // Read the text file and add each line to listBox1
                using (StreamReader sr = new StreamReader("top20.txt"))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        listBox1.Items.Add(line);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading file: " + ex.Message);
            }
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            

            if (transferCount >= 10)
            {
                listBox2.Visible = true;
                String top10 = @"C:\Users\Justiniane\OneDrive\Desktop\MissUniverse\MissUniverse\bin\Debug\top10.txt";
                String[] items = new string[listBox2.Items.Count];
                for (int i = 0; i < listBox2.Items.Count && i < 10; i++)
                {
                    items[i] = listBox2.Items[i].ToString();
                }
                File.WriteAllLines(top10, items);

                MessageBox.Show("top 10 printed to text file, please check directory");
            }
            else
                MessageBox.Show("Please select 10 Countries");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            

            if (transferCount2 >= 5)
            {
                listBox3.Visible = true;
                String top5 = @"C:\Users\Justiniane\OneDrive\Desktop\MissUniverse\MissUniverse\bin\Debug\top5.txt";
                String[] items = new string[listBox3.Items.Count];
                for (int i = 0; i < listBox3.Items.Count && i < 10; i++)
                {
                    items[i] = listBox3.Items[i].ToString();
                }
                File.WriteAllLines(top5, items);

                MessageBox.Show("top 5 printed to text file, please check directory");
            }
            else
                MessageBox.Show("Please select 5 Countries");
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (transferCount3 >= 1)
            {
                listBox4.Visible = true;
                String top1 = @"C:\Users\Justiniane\OneDrive\Desktop\MissUniverse\MissUniverse\bin\Debug\top1.txt";
                String[] items = new string[listBox4.Items.Count];

                for (int i = 0; i < listBox4.Items.Count && i < 10; i++)
                {
                    items[i] = listBox4.Items[i].ToString();
                }
                File.WriteAllLines(top1, items);

                MessageBox.Show("top 1 printed to text file, please check directory");
            }
            else
                MessageBox.Show("Please select 1 Country");

        }
    
        private int transferCount = 0;
        private void button4_Click(object sender, EventArgs e)
        {
            if (transferCount < 10)
            {

                string selectedItem = (string)listBox1.SelectedItem;


                listBox2.Items.Add(selectedItem);


                listBox1.Items.Remove(selectedItem);

                transferCount++;
            }
        

            else
            {
                MessageBox.Show("You can't transfer any more items. The maximum number of country allowed is 10.");
            }
        }
        private int transferCount2 = 0;
        private void button5_Click(object sender, EventArgs e)
        {
            if (transferCount2 < 5)
            {

                string selectedItem = (string)listBox2.SelectedItem;


                listBox3.Items.Add(selectedItem);


                listBox2.Items.Remove(selectedItem);

                transferCount2++;
            }
            else {
                MessageBox.Show("You can't transfer any more items. The maximum number of country allowed is 5.");
            }
        }
        private int transferCount3 = 0;
        private void button6_Click(object sender, EventArgs e)
        {
            if (transferCount3 < 1)
            {

                string selectedItem = (string)listBox3.SelectedItem;


                listBox4.Items.Add(selectedItem);
                listBox3.Items.Remove(selectedItem);
                MessageBox.Show("The Miss Universe is: " + selectedItem);


                transferCount3++;
            }

            else
            {
                MessageBox.Show("You can't transfer any more items. The maximum number of country allowed is 1.");
            }           
            
        }

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}


